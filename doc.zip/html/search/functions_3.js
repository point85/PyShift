var searchData=
[
  ['deletenonworkingperiod_0',['deleteNonWorkingPeriod',['../classwork__schedule_1_1_work_schedule.html#a7700f15cecee0e79092974198d22b8ed',1,'work_schedule::WorkSchedule']]],
  ['deleteshift_1',['deleteShift',['../classwork__schedule_1_1_work_schedule.html#a9ffd3db1e7c3d31c02ad3842ca5917a2',1,'work_schedule::WorkSchedule']]],
  ['deleteteam_2',['deleteTeam',['../classwork__schedule_1_1_work_schedule.html#abc815622a0cd7e7c15826cd2eeb05d86',1,'work_schedule::WorkSchedule']]]
];
