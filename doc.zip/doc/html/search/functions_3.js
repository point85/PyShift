var searchData=
[
  ['deletenonworkingperiod_0',['deleteNonWorkingPeriod',['../classwork__schedule_1_1_work_schedule.html#a4980e8152e486895e29d55572851d541',1,'work_schedule::WorkSchedule']]],
  ['deleteshift_1',['deleteShift',['../classwork__schedule_1_1_work_schedule.html#ad0e78a3910d1f69bc617c7a0220c45db',1,'work_schedule::WorkSchedule']]],
  ['deleteteam_2',['deleteTeam',['../classwork__schedule_1_1_work_schedule.html#a6f698de08f46c831d17d96229ae0b67c',1,'work_schedule::WorkSchedule']]]
];
