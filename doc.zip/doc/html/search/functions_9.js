var searchData=
[
  ['removebreak_0',['removeBreak',['../classshift_1_1_shift.html#a3f8b4fd9de07f804ec457fb6edab06cb',1,'shift::Shift']]]
];
