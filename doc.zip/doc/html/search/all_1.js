var searchData=
[
  ['addbreak_0',['addBreak',['../classshift_1_1_shift.html#a45984f25236dcf5ae916606a72dbc91e',1,'shift::Shift']]],
  ['addsegment_1',['addSegment',['../classrotation_1_1_rotation.html#af17556e7beee575546eba0c4b6f29787',1,'rotation::Rotation']]]
];
