var searchData=
[
  ['localizer_0',['Localizer',['../classlocalizer_1_1_localizer.html',1,'localizer']]]
];
